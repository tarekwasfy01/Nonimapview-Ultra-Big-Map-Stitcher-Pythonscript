@echo off

java -Xms2G -Xmx1000G -jar NoniMapViewV0.33.jar
pause